'use strict';
var myApp = myApp || {};
myApp.providers = myApp.providers || {};

myApp.providers.pinterest = (function(){
	function PinterestProvider(pageUrl){
		this.pageUrl = pageUrl;
	} 
	myApp.helpers.inherit(PinterestProvider, myApp.AbstractProvider);
	
	PinterestProvider.prototype.getSocialCount = function(){
		//Return the number of pins
		//var that = this;
		//return new Promise(function(resolve, reject){
		return $.ajax({
				dataType: 'jsonp',	
				url: 'https://api.pinterest.com/v1/urls/count.json?url=' + encodeURI(this.pageUrl),	
				success: function(response){
					return response;
				}}).promise();		
		//})
	};
	return PinterestProvider;
}());