'use strict';
var myApp = myApp || {};
myApp.providers = myApp.providers || {};

myApp.providers.twitter = (function(){
	function TwitterProvider(pageUrl){
		this.pageUrl = pageUrl; 
	}
	myApp.helpers.inherit(TwitterProvider, myApp.AbstractProvider);
	// TwitterProvider.prototype.setPageUrl = function(pageUrl){
	// 	this.options.pageUrl = pageUrl;
	// }
	//= Object.create(AbstractProvider);	
	TwitterProvider.prototype.getSocialCount = function(){
		//Return the number of tweets
		//var that = this;
		//return new Promise(function(resolve, reject){
		return $.ajax({
				dataType: 'jsonp',				
				url: 'http://urls.api.twitter.com/1/urls/count.json?url=' + encodeURI(this.pageUrl),	
				success: function(response){
					return response;
			}}).promise();		
		//})
	};
	return TwitterProvider;
}());