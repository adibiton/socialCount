'use strict';
var myApp = myApp || {};

myApp.providerFactory = (function(){
	function ProviderFactory(){}
	ProviderFactory.prototype.createProvider = function (options){		
		this.checkIfProviderExist(options.providerName);

		// switch(options.providerName){
		// 	case 'facebook':				
		// 		this.providerClass = myApp.providers.facebook;
		// 		break;
		// 	case 'twitter':
		// 		this.providerClass = myApp.providers.twitter;
		// 		break;
		// 	case ''
		// }
		return new myApp.providers[options.providerName](options.pageUrl);
	};

	ProviderFactory.prototype.checkIfProviderExist = function(providerName){
		if(typeof myApp.providers[providerName] !== 'function'){
			throw new Error(providerName + " provider doesn't exist");
			//console.error(providerName + " doesn't exist");			
		}
	} 
	return new ProviderFactory();
}());
	