'use strict';
var myApp = myApp || {};
myApp.providers = myApp.providers || {};

myApp.providers.facebook = (function(){
	function FacebookProvider(pageUrl){
		this.pageUrl = pageUrl;
	}
	myApp.helpers.inherit(FacebookProvider, myApp.AbstractProvider);
	// FacebookProvider.prototype.setPageUrl = function(pageUrl){
	// 	this.options.pageUrl = pageUrl;
	// }
	//= Object.create(AbstractProvider);
	FacebookProvider.prototype.getSocialCount = function(){
		//Return the number of likes, shares & comments
		//var that = this;
		//return new Promise(function(resolve, reject){
		return $.ajax({
			url: 'https://api.facebook.com/method/fql.query?query=' + encodeURI('select url, like_count, share_count, comment_count from link_stat where url=\'' + this.pageUrl + '\'') + 
					'&format=json',	
			success: function(response){
				return response[0];
			}}).promise();		
		//});
	};
	return FacebookProvider;
}());